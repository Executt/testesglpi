<?php

use Glpi\Event;

function plugin_stsync_install()
{
   PluginStsyncConfig::create_fields();

   return true;
}

function plugin_stsync_uninstall()
{
   PluginStsyncConfig::drop_fields();

   return true;
}

/**
 * Function to authenticate and obtain a session token from GLPI.
 *
 * @param string $url The URL of the GLPI server.
 * @param string $username The username for authentication.
 * @param string $password The password for authentication.
 * @return string|null The session token or null on failure.
 */
function authenticateAndGetToken($url, $username, $password, $app_token = "")
{
   $apiUrl = $url . '/apirest.php/initSession';

   // Prepare Basic Authentication header
   $authHeader = 'Authorization: Basic ' . base64_encode($username . ':' . $password);

   $headers = array(
      $authHeader,
      'Content-Type: application/json',
      'App-Token: ' . $app_token
   );

   $ch = curl_init($apiUrl);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
   curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

   $response = curl_exec($ch);

   if (curl_errno($ch)) {
      echo 'Error in the request: ' . curl_error($ch);
      return null;
   }

   curl_close($ch);

   // Process the response
   $responseData = json_decode($response, true);

   // Check if the response contains the session token
   if (isset($responseData['session_token'])) {
      return $responseData['session_token'];
   } else {
      echo 'Authentication failed. Response: ' . $response;
      return null;
   }
}

/**
 * Function to integrate with GLPI via API REST.
 *
 * @param string $url The URL of the GLPI server.
 * @param string $token The authentication token for accessing the GLPI API.
 * @param any $item The CommonDBTM or StdClass object representing the item to be updated.
 * @return string The response from the GLPI API.
 */
function integrateWithGLPI($item, $method = "POST", $forcePurge = false)
{
   $glpiUrl = PluginStsyncConfig::getConfig('glpi_url');
   $glpiUsername = PluginStsyncConfig::getConfig('glpi_username');

   $glpiPassword = PluginStsyncConfig::getConfig('glpi_password');
   $glpiPassword = empty($glpiPassword) ? "" : PluginStsyncConfig::decrypt($glpiPassword);

   $glpiAppToken = PluginStsyncConfig::getConfig('glpi_app_token');
   $glpiAppToken = empty($glpiAppToken) ? "" : PluginStsyncConfig::decrypt($glpiAppToken);

   $itemType = $item->stsynctype ?? $item->getType();

   if (empty($glpiUrl) || empty($glpiUsername) || empty($glpiPassword)) return false;
   if (in_array($method, ["PUT", "DELETE"]) && empty($item->fields["stsync_id"])) return;
   if (
      in_array($method, ["POST"]) 
      && $itemType != "Ticket"
      && (isset($item->input["items_id"]) || isset($item->input["tickets_id"]))
      && method_exists($item, 'getItem') && empty($item->getItem()->fields['stsync_id'])
   ) return;

   $glpiToken = authenticateAndGetToken($glpiUrl, $glpiUsername, $glpiPassword, $glpiAppToken);

   $apiUrl = $glpiUrl . '/apirest.php/' . $itemType;

   $item->input['custom_fields'] = empty($item->input['custom_fields']) 
      ? ['api' => true] : array_merge($item->input['custom_fields'], ['api' => true]);

   // Send to field to remote glpi
   $item->input["stsync_id"] = $item->fields['id'];

   // Send stsync_id as ip to remote glpi ( update or delete )
   if (in_array($method, ["PUT", "DELETE"])) {
      $item->input['id'] = $item->fields["stsync_id"];
   } else if (in_array($method, ["POST"]) && $itemType != "Ticket" && method_exists($item, 'getItem')) {
      if (isset($item->input["items_id"])) $item->input["items_id"] = $item->getItem()->fields['stsync_id'];
      if (isset($item->input["tickets_id"])) $item->input["tickets_id"] = $item->getItem()->fields['stsync_id'];
   }
   
   $data = array(
      'input' => $item->input
   );

   if ($forcePurge) $data['force_purge'] = true;

   $headers = array(
      'Session-Token: ' . $glpiToken,
      'Content-Type: application/json',
      'App-Token: ' . $glpiAppToken
   );

   $ch = curl_init($apiUrl);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
   curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
   curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

   $response = curl_exec($ch);

   if (curl_errno($ch)) {
      $response = 'Error in the request: ' . curl_error($ch);
   }

   // statusCode
   $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

   curl_close($ch);

   // Process the response if needed
   return [
      'response' => $response,
      'statusCode' => $statusCode
   ];
}

function writeLogEvent(CommonDBTM $item, $message) {
   Event::log(
      0,
      strtolower($item->getType()),
      3,
      "plugin",
      $message
   );
}

function ignoreHookByRules(CommonDBTM $item) {
   return !empty($item->input['custom_fields']['api']);
}


function getApiReturnedId($apiResponse) {
   if (!empty($apiResponse['response'])) {
      try {
         return json_decode($apiResponse['response'], true)['id'];
      } catch (\Exception $ea) {}
   }
}

function updateItemStsyncId(CommonDBTM $item, $apiResponse) {
   if (!empty($apiResponse['response'])) {
      try {
         $stsync_id = json_decode($apiResponse['response'], true)['id'];

         $item->update([
            "id" => $item->fields['id'],
            "stsync_id" => $stsync_id
         ]);
      } catch (\Exception $ea) {}
   }
}

function sendIntegration($item) {
   $apiResponse = integrateWithGLPI($item, "POST");

   if (empty($apiResponse)) return;

   if (!in_array($apiResponse['statusCode'], [200, 201])) {
      writeLogEvent($item, "SYNC API => [STATUS: " . $apiResponse['statusCode'] . "] " . $apiResponse['response']);
   }
}

// #############################################
// ##############    TICKET     ################
// #############################################
function plugin_stsync_ticket_add(CommonDBTM $item)
{
   try {
      if (ignoreHookByRules($item)) return;

      $categoriaId = PluginStsyncConfig::getConfig('glpi_category_id');
      $requisicaoId = PluginStsyncConfig::getConfig('glpi_origem_requisicao_id');
      $requerenteId = PluginStsyncConfig::getConfig('glpi_origem_requerente_id');
      $entidadeId = PluginStsyncConfig::getConfig('glpi_entity');
      // $fornecedorId = PluginStsyncConfig::getConfig('glpi_origem_fornecedor_id');
      // $grupoObservadorId = PluginStsyncConfig::getConfig('glpi_origem_grupo_observador_id');

      if (
         empty($categoriaId) 
         || empty($requisicaoId) 
         || empty($requerenteId)
         || (!isset($entidadeId) || $entidadeId == "")
         // || empty($fornecedorId)
         // || empty($grupoObservadorId)
      ) return;

      $triggerCategories = PluginStsyncConfig::getConfig('glpi_trigger_categories');
      $triggerRequerentes = PluginStsyncConfig::getConfig('glpi_trigger_requerentes');
      $triggerFornecedores = PluginStsyncConfig::getConfig('glpi_trigger_fornecedores');
      $triggerGrupoObservador = PluginStsyncConfig::getConfig('glpi_trigger_grupo_observador');

      if (
         empty($triggerCategories) 
         && empty($triggerRequerentes) 
         && empty($triggerFornecedores)
         && empty($triggerGrupoObservador)
      ) return;

      $triggerCategories = array_values(array_filter(array_map('trim', explode(';', $triggerCategories ?? ""))));
      $triggerRequerentes = array_values(array_filter(array_map('trim', explode(';', $triggerRequerentes ?? ""))));
      $triggerFornecedores = array_values(array_filter(array_map('trim', explode(';', $triggerFornecedores ?? ""))));
      $triggerGrupoObservador = array_values(array_filter(array_map('trim', explode(';', $triggerGrupoObservador ?? ""))));

      // VALID CATEGORIES

      $doIntegration = false;

      if (!empty($item->input['itilcategories_id']) 
         && in_array($item->input['itilcategories_id'], $triggerCategories)
      ) $doIntegration = true;
      
      if (!empty($item->input['itilcategories_id'])) $item->input['itilcategories_id'] = $categoriaId;

      // #####################

      // VALID ORIGEM REQUISICAO

      if (!empty($item->input['requesttypes_id'])) $item->input['requesttypes_id'] = $requisicaoId;

      // #####################

      // VALID ENTIDADE

      if (isset($item->input['entities_id'])) $item->input['entities_id'] = $entidadeId;

      // #####################

      // VALID REQUERENTE

      if (!empty($item->input["_users_id_requester"])) {
         $clonedRequester = $item->input["_users_id_requester"];
   
         foreach ($clonedRequester as $key => $reqValue) {
            if (in_array($reqValue, $triggerRequerentes)) {
               if (!$doIntegration) $doIntegration = true;
      
               break;
            }
         }
      }

      $reqValue = [];
      $reqValue["_actors_" . $requerenteId] = $requerenteId;
      $item->input["_users_id_requester"] = $reqValue;

      // #####################

      // VALID FORNECEDORES

      if (!empty($item->input["_suppliers_id_assign"])) {
         $clonedSupplier = $item->input["_suppliers_id_assign"];
   
         foreach ($clonedSupplier as $key => $reqValue) {
            if (in_array($reqValue, $triggerFornecedores)) {
               if (!$doIntegration) $doIntegration = true;
   
               break;
            }
         }
      }

      // #####################

      // VALID GRUPO OBSERVADOR

      if (!empty($item->input["_groups_id_assign"])) {
         $clonedGroupObserver = $item->input["_groups_id_assign"];
   
         foreach ($clonedGroupObserver as $key => $reqValue) {
            if (in_array($reqValue, $triggerGrupoObservador)) {
               if (!$doIntegration) $doIntegration = true;
   
               break;
            }
         }
      }

      // #####################

      // Se atende pelo menos uma trigger, entao realiza a integracao
      if (!$doIntegration) return;
      
      $apiResponse = integrateWithGLPI($item, "POST");

      if (empty($apiResponse)) return;
   
      if (!in_array($apiResponse['statusCode'], [200, 201])) {
         writeLogEvent($item, "SYNC API => [STATUS: " . $apiResponse['statusCode'] . "] " . $apiResponse['response']);
      }

      // UPDATE SYNC ID
      updateItemStsyncId($item, $apiResponse);

      $idRemote = getApiReturnedId($apiResponse);

      if ($idRemote) {
         $glpiUrl = PluginStsyncConfig::getConfig('glpi_url', "");
         $urlServer = "http" . (isset($_SERVER['HTTPS']) ? "s" : "") . "://" . $_SERVER['HTTP_HOST'];

         // CREATE FOLLOW ON REMOTE
         $itemFollow = new stdClass();
         $itemFollow->stsynctype = "ITILFollowup";
         $itemFollow->input = [
            "itemtype" => "Ticket",
            "items_id" => $idRemote,
            "content" => ("<b>Chamado com Integração:</b><br><br><b>Servidor:</b> [" . $urlServer . "]<br><b>Nº do chamado:</b> #" . $item->fields['id']),
            "custom_fields" => ["api" => true, "followup_message_update_id" => $item->fields['id']]
         ];

         // SEND FOLLOWUP INTEGRATION
         sendIntegration($itemFollow);

         // CREATE FOLLOW
         $fup = new ITILFollowup();
         
         $fupinput = [
            "itemtype" => "Ticket",
            "items_id" => $item->fields['id'],
            "content" => ("<b>Chamado com Integração:</b><br><br><b>Servidor:</b> [" . $glpiUrl . "]<br><b>Nº do chamado:</b> #" . $idRemote),
            "custom_fields" => ["api" => true]
         ];

         $fup->add($fupinput);
      }
   } catch (\Exception $e) {}
}

// function plugin_stsync_ticket_update(CommonDBTM $item)
// {
//    try {
//       if (ignoreHookByRules($item)) return;

//       $apiResponse = integrateWithGLPI($item, "PUT");

//       if (empty($apiResponse)) return;
   
//       if (!in_array($apiResponse['statusCode'], [200, 201])) {
//          writeLogEvent($item, "SYNC API => [STATUS: " . $apiResponse['statusCode'] . "] " . $apiResponse['response']);
//       }
//    } catch (\Exception $e) {}
// }

// function plugin_stsync_ticket_delete(CommonDBTM $item)
// {
//    try {
//       if (ignoreHookByRules($item)) return;

//       $apiResponse = integrateWithGLPI($item, "DELETE");

//       if (empty($apiResponse)) return;
   
//       if (!in_array($apiResponse['statusCode'], [200, 201])) {
//          writeLogEvent($item, "SYNC API => [STATUS: " . $apiResponse['statusCode'] . "] " . $apiResponse['response']);
//       }
//    } catch (\Exception $e) {}
// }

// function plugin_stsync_ticket_purge(CommonDBTM $item)
// {
//    try {
//       if (ignoreHookByRules($item)) return;

//       $apiResponse = integrateWithGLPI($item, "DELETE", true);

//       if (empty($apiResponse)) return;
   
//       if (!in_array($apiResponse['statusCode'], [200, 201])) {
//          writeLogEvent($item, "SYNC API => [STATUS: " . $apiResponse['statusCode'] . "] " . $apiResponse['response']);
//       }
//    } catch (\Exception $e) {}
// }

// #############################################
// ############## TICKET FOLLOW ################
// #############################################
function plugin_stsync_ticketfollow_add(CommonDBTM $item)
{
   try {
      if (isset($item->input['custom_fields']['api']) && isset($item->input['custom_fields']['followup_message_update_id'])) {
         $glpiUrl = PluginStsyncConfig::getConfig('glpi_url', "");

         if (!empty($glpiUrl)) {
            $item->update([
               "content" => ("<b>Chamado com Integração:</b><br><br><b>Servidor:</b> [" . $glpiUrl . "]<br><b>Nº do chamado:</b> #" . $item->input['custom_fields']['followup_message_update_id']),
            ]);
         }
      }

      if (ignoreHookByRules($item)) return;

      if (isset($item->fields['itemtype']) && $item->fields['itemtype'] != "Ticket") return;

      // Remove vinculo de usuario ao follow
      unset($item->input['users_id']);

      $apiResponse = integrateWithGLPI($item, "POST");

      if (empty($apiResponse)) return;
   
      if (!in_array($apiResponse['statusCode'], [200, 201])) {
         writeLogEvent($item, "SYNC API => [STATUS: " . $apiResponse['statusCode'] . "] " . $apiResponse['response']);
      }

      // UPDATE SYNC ID
      updateItemStsyncId($item, $apiResponse);
   } catch (\Exception $e) {}
}

// function plugin_stsync_ticketfollow_update(CommonDBTM $item)
// {
//    try {
//       if (ignoreHookByRules($item)) return;

//       if ($item->fields['itemtype'] != "Ticket") return;

//       $apiResponse = integrateWithGLPI($item, "PUT");

//       if (empty($apiResponse)) return;
   
//       if (!in_array($apiResponse['statusCode'], [200, 201])) {
//          writeLogEvent($item, "SYNC API => [STATUS: " . $apiResponse['statusCode'] . "] " . $apiResponse['response']);
//       }
//    } catch (\Exception $e) {}
// }

// function plugin_stsync_ticketfollow_delete(CommonDBTM $item)
// {
//    try {
//       if (ignoreHookByRules($item)) return;

//       if ($item->fields['itemtype'] != "Ticket") return;

//       $apiResponse = integrateWithGLPI($item, "DELETE");

//       if (empty($apiResponse)) return;
   
//       if (!in_array($apiResponse['statusCode'], [200, 201])) {
//          writeLogEvent($item, "SYNC API => [STATUS: " . $apiResponse['statusCode'] . "] " . $apiResponse['response']);
//       }
//    } catch (\Exception $e) {}
// }

// function plugin_stsync_ticketfollow_purge(CommonDBTM $item)
// {
//    try {
//       if (ignoreHookByRules($item)) return;

//       if ($item->fields['itemtype'] != "Ticket") return;

//       $apiResponse = integrateWithGLPI($item, "DELETE", true);

//       if (empty($apiResponse)) return;
   
//       if (!in_array($apiResponse['statusCode'], [200, 201])) {
//          writeLogEvent($item, "SYNC API => [STATUS: " . $apiResponse['statusCode'] . "] " . $apiResponse['response']);
//       }
//    } catch (\Exception $e) {}
// }

// #############################################
// ############## TICKET TASKS ################
// #############################################
function plugin_stsync_tickettask_add(CommonDBTM $item)
{
   try {
      if (ignoreHookByRules($item)) return;

      // Remove vinculo de usuario a task
      unset($item->input['users_id']);

      $apiResponse = integrateWithGLPI($item, "POST");

      if (empty($apiResponse)) return;
   
      if (!in_array($apiResponse['statusCode'], [200, 201])) {
         writeLogEvent($item, "SYNC API => [STATUS: " . $apiResponse['statusCode'] . "] " . $apiResponse['response']);
      }

      // UPDATE SYNC ID
      updateItemStsyncId($item, $apiResponse);
   } catch (\Exception $e) {}
}

// #############################################
// ############## TICKET FOLLOW ################
// #############################################
function plugin_stsync_ticketsolution_add(CommonDBTM $item)
{
   try {
      if (ignoreHookByRules($item)) return;

      if (isset($item->fields['itemtype']) && $item->fields['itemtype'] != "Ticket") return;

      // Remove vinculo de usuario a solution
      unset($item->input['users_id']);

      $apiResponse = integrateWithGLPI($item, "POST");

      if (empty($apiResponse)) return;
   
      if (!in_array($apiResponse['statusCode'], [200, 201])) {
         writeLogEvent($item, "SYNC API => [STATUS: " . $apiResponse['statusCode'] . "] " . $apiResponse['response']);
      }

      // UPDATE SYNC ID
      updateItemStsyncId($item, $apiResponse);
   } catch (\Exception $e) {}
}
